<?php
/**
 * Created by PhpStorm.
 * User: dell
 * Date: 2/19/2019
 * Time: 11:15
 */?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Email Tests</title>
</head>
<body>

<a href="smtp_test.php">Mail Test</a><br>
<a href="config_test.php">ConfigView</a><br>
<a href="display_test.php">Mail HTML Render test</a>
</body>
</html>
